package com.sbi.employee;

public class Director extends Manager
{
	public void direct(Person p,Employee e) 
	{
		System.out.println("Age   "+p.age);
		System.out.println("Name   "+p.name);
		e.occupation();
		e.worktimings();
		
		System.out.println(p.name+" will be Director at "+(p.age+20)+"  years");
		
		
	}
			
		

}
