package com.sbi.employee;

import com.sbi.livingBeing.CognitiveAbility;

public abstract class Employee extends Student {

	
	private static final Person p=null;
	private static final Subject s=null;
	
	@Override
	public void getName() {
		// TODO Auto-generated method stub
		super.getName();
	}

	@Override
	public void getAge() {
		// TODO Auto-generated method stub
		super.getAge();
	}

	@Override
	public void occupation() {
		// TODO Auto-generated method stub
		super.occupation();
	}

	@Override
	public void warmblooded(CognitiveAbility c) {
		// TODO Auto-generated method stub
		super.warmblooded(c);
		
	}
	//arguments of type Person and Subject is passed respectively
	public void showMarks() {
		super.giveExam(p, s);
		}
	
	public void worktimings() {
		System.out.println("the work hours are from 10 to 7");
	}
	
}
