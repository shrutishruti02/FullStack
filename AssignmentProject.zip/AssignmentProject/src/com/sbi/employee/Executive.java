package com.sbi.employee;

public class Executive extends Employee {

	
	public void execute() {
		// TODO Auto-generated method stub
		System.out.println("Executive at 35......");
		
	}
}
