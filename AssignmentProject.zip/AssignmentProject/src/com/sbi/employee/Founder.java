package com.sbi.employee;

public class Founder extends Director  {

	public void found(Person p) {
		System.out.println(p.name+" will be a Founder at the age of .."+((p.age)+40)+" years");
		p.live();
		p.die();
		
	}
	

}

