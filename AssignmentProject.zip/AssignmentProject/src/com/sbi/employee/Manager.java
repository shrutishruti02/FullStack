package com.sbi.employee;

public class Manager extends Executive {

		
	
	public void manage() {
		
		System.out.println("Manager at age 40");
	}

	
}
