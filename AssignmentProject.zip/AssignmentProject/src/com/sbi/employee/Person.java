package com.sbi.employee;
import com.sbi.livingBeing.*;
import java.util.*;

interface Features 
{
	void activity();
	void occupation();
	void getAge();
	void getName();
	
}
public class Person extends Human implements Features{
	 static String name;
	 static int age;
	
	
	@Override
	public void getAge() {
		
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter your age");
		age=sc.nextInt();
		System.out.println("Age of person is"+age);
	
	}
	@Override
	public void getName() {
		
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter your name");
		name=sc.nextLine();
		System.out.println("Name of Person is"+name);
	}
	
	
	@Override
	public void activity() {
		
		System.out.println("Person is active");
	}
	@Override
	public void occupation() {
		
		String job;
		Scanner sc=new Scanner(System.in);
		System.out.println("Whats your job?");
		job=sc.nextLine();
		System.out.println("Job is "+job);
	}

	

}
