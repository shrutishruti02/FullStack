package com.sbi.employee;


public class Student extends Person implements Result {
	
		//Result r=new Student();
		@Override
		public void getName() {
		// TODO Auto-generated method stub
		super.getName();
		}
		
		
		
		@Override
		public void getAge() {
			// TODO Auto-generated method stub
			super.getAge();
		}

		

		void giveExam(Person p,Subject s) {
						
			System.out.println(p.name+"  of age  "+p.age+" is writing Exam on "+s.sub +" and scored "+Subject.marks);
			//System.out.println(r);
			
			
			
			
		}



		@Override
		public void calculate() {
			// TODO Auto-generated method stub
			System.out.println("The marks is 100");
		}



		@Override
		public void grade() {
			// TODO Auto-generated method stub
			System.out.println("The Grade is A");
			
		}
}

interface Result extends Subject
{
	
	void grade();
	
}
interface Subject{
	String sub="Maths";
	static int marks=100;
	void calculate();
	
}