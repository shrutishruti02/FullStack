package com.sbi.livingBeing;

public interface Animal {
	void live();
	void die();
	void hunt();
	void eat();
	void reproduce();

}
