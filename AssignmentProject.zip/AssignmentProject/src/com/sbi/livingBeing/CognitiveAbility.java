package com.sbi.livingBeing;

public class CognitiveAbility {
	 
	protected void think() {
		System.out.println("Humans can think...........");
	}

}
