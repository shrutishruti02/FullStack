package com.sbi.livingBeing;

public class Human implements Mammal {

	public void live(Lungs b) {
		// TODO Auto-generated method stub
		System.out.println("Humans breathe to live.........");
		b.noofLungs();
		b.breathein();
		b.breatheout();
		
			
	}
	// implements Mammal's methods
	@Override
	public void die() {
		// TODO Auto-generated method stub
		System.out.println("Humans die of old age and diseases........");
	}

	@Override
	public void hunt() {
		// TODO Auto-generated method stub
		System.out.println("Humans living in forests hunt their food...........");

	}

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("eats food to satisfy hunger........");
	}

	@Override
	public void reproduce() {
		// TODO Auto-generated method stub
		System.out.println("reproduces.........");
	}

	@Override
	public void givebirth() {
		// TODO Auto-generated method stub
		System.out.println("Gives birth.......");
	}

	public void warmblooded(CognitiveAbility c) {
		// TODO Auto-generated method stub
		c.think();
		warmblooded();
	   
	}

	@Override
	public void warmblooded() {
		// TODO Auto-generated method stub
		System.out.println("Humans like mammals are warmblooded..........");
		
	}

	@Override
	public void live() {
		// TODO Auto-generated method stub
		System.out.println("Humans live for 70-80 yrs");
		
	}
}
 
	

