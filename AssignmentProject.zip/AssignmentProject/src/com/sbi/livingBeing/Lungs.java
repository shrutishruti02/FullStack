package com.sbi.livingBeing;

public class Lungs {
	public void breathein() {// hasA
		System.out.println("Breathe in....");
	}
	public void breatheout() {//hasA
		System.out.println("Breathe out");
	}
	@SuppressWarnings("unused")
	private void filtersAir()//will not be accessible to even  members of the same package
	{
		System.out.println("Filters Air flow in Lungs");
		
	}
	
	protected void noofLungs() {//will be accessed across classes of same package
		System.out.println("Humans have 2 lungs");
	}
	
	
}
