package com.sbi.livingBeing;

public interface Mammal extends Animal {

	void givebirth();
	void warmblooded();
	
}
