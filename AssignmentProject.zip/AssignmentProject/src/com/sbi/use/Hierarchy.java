package com.sbi.use;
import com.sbi.employee.*;
import com.sbi.livingBeing.*;

public class Hierarchy {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		Founder f=new Founder();
		Human h=new Human();
		h.live();
		
		Lungs b=new Lungs();
		h.live(b);
		
		h.eat();
		
		CognitiveAbility c=new CognitiveAbility();
		h.warmblooded(c);
		
		
		f.getAge();
		f.getName();
		System.out.println("---------------------");
		
		f.showMarks();
		f.grade();
		System.out.println("---------------------");
		
		
		//f.worktimings();

		//f.execute();
		//f.manage();
		Person p=new Person();
		Employee e=new Executive();
		
		f.direct(p,e);
		f.found(p);
		
		
	
			
	}

}
